Totomo WordPress theme, copyright (C) 2015 WPThemes9.
Totomo WordPress theme is licensed under GPLv2.

Totomo is a clean, faster, responsive WordPress theme for bloggers. When it comes to WordPress themes, less is definitely more, so with Totomo you get just the right amount of options and a clean design, letting your awesome content do the talking. Totomo also offers support for the following post formats: standard, image, gallery, audio, video, quote, link.

Totomo is based on Undescores, a starter theme from Automattic: http://underscores.me
Underscores WordPress theme is licensed under GPLv2 or later.

Licenses
---------------------
Totomo WordPress theme uses the following third-party resources:

* Bootstrap by Twitter set are licensed under the GPL-compatible [http://www.apache.org/licenses/LICENSE-2.0 Apache License v2.0]

* FitVids.js set are licensed under the WTFPL license - http://sam.zoy.org/wtfpl

* screenshot.png (slider image) CC0 Public Domain Reference: http://pixabay.com/go/?t=%2Fservice%2Fterms%2F%23download_terms, Image Source: http://pixabay.com/en/light-office-computer-business-300431/

FONTS
---------------------
* Lato - https://www.google.com/fonts/specimen/Lato
  License: Distributed under the terms of SIL Open Font License, 1.1, http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL
  Copyright: Łukasz Dziedzic, https://plus.google.com/106163021290874968147/about


* Font Awesome - http://fontawesome.io
  Font License: Distributed under the terms of SIL Open Font License, 1.1, http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL
  Code License: Distributed under the terms of MIT, http://opensource.org/licenses/mit-license.html
  Documentation License: Distributed under the terms of CC BY 3.0, http://creativecommons.org/licenses/by/3.0/
  Copyright: Dave Gandy, http://fontawesome.io
